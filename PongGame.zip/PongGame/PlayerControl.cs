﻿using System;

public class PlayerControl
{
	public struct PlayerControl
	{
        public int up;
        public int down;
    }
}
