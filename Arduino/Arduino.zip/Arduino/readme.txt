Folder: Get_Joystick_Signals
	Arduino Code

Folder: Arduino_GetSignals
	C# Application